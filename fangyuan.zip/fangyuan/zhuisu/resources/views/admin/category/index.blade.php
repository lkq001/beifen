@extends('admin.public.main')

@section('title', '方圆追溯系统')

@section('title_first', '分类管理')
@section('title_secound', '分类列表')

@section('main-title', '分类列表')

@section('content')
    <div class="page-container">

        <div class="mt-20">
            <table class="table table-border table-bordered table-bg table-hover table-sort">
                <thead>
                <tr class="text-c">
                    <th width="40">ID</th>
                    <th>名称</th>
                    <th>操作</th>
                </tr>
                </thead>
                <tbody>
                @foreach($categorys as $v)
                    <tr class="text-c va-m">
                        <td>{{$v->id}}</td>
                        <td>{{$v->name}}</td>

                        <td class="td-manage">
                            <a href="{{ route('admin.category.edit', ['id' => $v->id]) }}"><button class="label label-success radius">编辑</button></a>
                            <button class="label label-danger radius" id="destroy" data-id="{{$v->id}}" data-url="{{ route('admin.category.destroy') }}" >删除</button>

                        </td>
                    </tr>
                @endforeach
                </tbody>

            </table>
        </div>
    </div>
@endsection