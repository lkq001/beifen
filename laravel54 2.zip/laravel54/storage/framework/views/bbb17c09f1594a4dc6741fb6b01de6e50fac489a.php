<?php $__env->startSection('title', '宅配卡管理'); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">用户宅配卡列表</h3>
                </div>
                <div class="panel-body">

                    <!-- 添加 -->
                <?php echo $__env->make('admin.userCards.add', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <!-- 修改 -->
                    <?php echo $__env->make('admin.userCards.edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <table id="datatable" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>宅配卡名称</th>
                                    <th>用户名称</th>
                                    <th>宅配卡号</th>
                                    <th>剩余次数</th>
                                    <th>状态</th>
                                    <th>操作</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php $__currentLoopData = $userCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($card->id); ?></td>
                                        <td><?php echo e($card->username); ?></td>
                                        <td><?php echo e($card->number); ?></td>
                                        <td><?php echo e($card->number); ?></td>
                                        <td><?php echo e($card->number_count); ?></td>
                                        <td>

                                            <?php if( $card->status  == 1): ?>
                                                未激活
                                            <?php elseif($card->status == 2): ?>
                                                已激活
                                            <?php elseif($card->status == 3): ?>
                                                已用完
                                            <?php elseif($card->status == 4): ?>
                                                已失效
                                            <?php else: ?>
                                                其他
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <button id="user-cards-edit" class="btn-xs btn-info btn-rounded m-b-5"
                                                    data-id="<?php echo e($card->id); ?>"
                                                    data-url="<?php echo e(route('admin.user.cards.edit')); ?>">编辑
                                            </button>
                                            <button id="user-cards-destroy" class="btn-xs btn-danger btn-rounded m-b-5"
                                                    data-id="<?php echo e($card->id); ?>"
                                                    data-url="<?php echo e(route('admin.user.cards.destroy')); ?>">删除
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div> <!-- End Row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('admins')); ?>/js/userCards.js"></script>
    <script id="ueditor"></script>
    <script>
        var ue = UE.getEditor("ueditor");
        ue.ready(function () {
            //因为Laravel有防csrf防伪造攻击的处理所以加上此行
            ue.execCommand('serverparam', '_token', '<?php echo e(csrf_token()); ?>');
        });
    </script>

    <script id="editueditor"></script>
    <script>
        var ue = UE.getEditor("editueditor");
        ue.ready(function () {
            //因为Laravel有防csrf防伪造攻击的处理所以加上此行
            ue.execCommand('serverparam', '_token', '<?php echo e(csrf_token()); ?>');
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>