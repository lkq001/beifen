<?php
/**
 *
 *
 * Created by PhpStorm.
 * User: likeqin
 * Date: 2017/12/16
 * Time: 23:35
 * author 李克勤
 */
return [
    'token_expire_in' => 7200,
];