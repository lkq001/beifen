$(function () {

    function headerCsrf() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    }


    // 删除通用方法
    $('body').on('click', '#destroy', function (i) {
        var that = $(this);
        var id = that.attr('data-id');
        var url = that.attr('data-url');

        // ajax 请求数据

        swal({
                title: "确定删除吗？",
                text: "你将无法恢复该数据！",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "确定删除！",
                closeOnConfirm: false
            },
            function(){

                if (!url || !parseInt(id)) {
                    sweetAlert("", "提交数据格式错误！", "error");
                    return false;
                }
                headerCsrf();
                // 循环处理数据
                $.ajax({
                    url: url,
                    data: {'id' : id},
                    type: 'post',
                    success: function (res) {
                        console.log(res);
                        if (res.code == 200) {

                            that.parent().parent().remove();
                            swal("删除成功！", "确定！","success")

                        } else {
                            sweetAlert("", "删除失败！", "error");
                            return false;
                        }
                    },
                    error: function (res) {
                        sweetAlert("", "删除失败！", "error");
                        return false;
                    }
                });

            });
    });
});
