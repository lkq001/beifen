<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>绿行者</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <meta name="renderer" content="webkit">
    <meta name="robots" content="index,follow"/>
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="format-detection" content="telphone=no, email=no"/>
    <meta http-equiv="Cache-Control" content="no-siteapp"/>
    <meta name="baidu-site-verification" content="eAsfmG0pun"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/css/style.css')); ?>">
    <script type="text/javascript" src="<?php echo e(asset('home/js/flexible.js')); ?>"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

    <style>

        .main .part1 p:nth-of-type(3) {
            margin-bottom: 0.46875rem;
            color: #000;
            font-size: 0.34375rem;
            text-align: center; }
        .main .part1 p:nth-of-type(3) span {
            margin: 0 0.39063rem;
            color: #005d32;
            font-size: 0.46875rem; }
        .main .part1 p:nth-of-type(4) {
            margin-bottom: 0.46875rem;
            color: #000;
            font-size: 0.34375rem;
            text-align: center; }
        .main .part1 p:nth-of-type(4) span {
            margin: 0 0.39063rem;
            color: #005d32;
            font-size: 0.46875rem; }
        .m-10 {
            margin-top: 10px;
        }
    </style>

</head>
<body>
<header onclick="indexTo()" id="index_url" data-url="<?php echo e(route('home.index.index', ['id' => $id])); ?>">
    <a class="tmall" href="">天猫商城</a>
    <a class="wechat" href="https://j.youzan.com/Ojjvkh">微信商城</a>
    <img class="logo" src="<?php echo e(asset('home/images/logo.png')); ?>" alt="绿行者">
</header>
<nav>
    <a href="<?php echo e(route('home.pages.company')); ?>">公司介绍</a>
    <a href="<?php echo e(route('home.pages.brand')); ?>">品牌介绍</a>
    <a href="<?php echo e(route('home.pages.base')); ?>">基地介绍</a>
    <a href="<?php echo e(route('home.evaluate.index')); ?>">意见反馈</a>
</nav>
<section class="main">
    <div class="part1">
        <p><?php echo e($info->title); ?></p>
        <img src="<?php echo e($info->image); ?>" alt="">
        <?php echo $info->codeImage; ?>

        <p><?php echo e($info->code); ?></p>
        <p><?php echo e($info->address); ?></p>
        <div class="tree">
            <span><?php echo e($info->to_the_store_name); ?>：<em><?php echo e($info->to_the_store); ?></em></span>
            <span><?php echo e($info->transport_name); ?>：<em><?php echo e($info->transport); ?></em></span>
            <span><?php echo e($info->packing_name); ?>：<em><?php echo e($info->packing); ?></em></span>
            <span><?php echo e($info->pick_name); ?>：<em><?php echo e($info->pick); ?></em></span>
            <span><?php echo e($info->pest_control_name); ?>：<em><?php echo e($info->pest_control); ?></em></span>
            <span><?php echo e($info->bear_fruit_name); ?>：<em><?php echo e($info->bear_fruit); ?></em></span>
            <span><?php echo e($info->fertilization_name); ?>：<em><?php echo e($info->fertilization); ?></em></span>
            <span><?php echo e($info->bloom_name); ?>：<em><?php echo e($info->bloom); ?></em></span>
            <span><?php echo e($info->trim_crop_name); ?>：<em><?php echo e($info->trim_crop); ?></em></span>
            <span><?php echo e($info->colonization_name); ?>：<em><?php echo e($info->colonization); ?></em></span>
            <span><?php echo e($info->grow_seedlings_name); ?>：<em><?php echo e($info->grow_seedlings); ?></em></span>
        </div>

        
        <img src="<?php echo e(asset('home/images/img4.png')); ?>" alt="">
    </div>
    <div class="part2">
        <?php echo $info->content; ?>

    </div>
</section>
<footer>
    <img class="logo" src="<?php echo e(asset('home/images/logo.png')); ?>" alt="绿行者">
    <span>
			<img src="<?php echo e(asset('home/images/wechat-code.jpg')); ?>" alt="微信服务号">微信服务号
		</span>
    <span>
			<img src="<?php echo e(asset('home/images/weibo-code.png')); ?>" alt="微博二维码">微博二维码
		</span>
    <p class="contact">官方客服电话<br>400-658-0088</p>
    <p>国际标准蔬菜&nbsp;就选绿行者</p>
</footer>
</body>
<script>
    function indexTo() {
        var url = $('#index_url').attr('data-url');
        location.href = url
    }
</script>
</html>
