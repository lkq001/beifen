@extends('admin.public.main')

@section('title', '方圆追溯系统')

@section('title_first', '评价管理')
@section('title_secound', '评价列表')

@section('main-title', '评价')

<style type="text/css">
    .pagination {
        display: inline-block;
        padding-left: 0;
        margin: 20px 0;
        border-radius: 4px;
    }
    .pagination ul {
        list-style-type: disc;
        -webkit-margin-before: 1em;
        -webkit-margin-after: 1em;
        -webkit-margin-start: 0px;
        -webkit-margin-end: 0px;
        -webkit-padding-start: 40px;
    }
    .pagination li {
        display: inline;
    }
    .pagination li span {
        z-index: 3;
        cursor: default;
        position: relative;
        float: left;
        padding: 6px 12px;
        margin-left: -1px;
        line-height: 1.42857143;
        color: #337ab7;
        text-decoration: none;
        background-color: #fff;
        border: 1px solid #ddd;
    }
    .pagination .active span {
        z-index: 3;
        color: #fff;
        cursor: default;
        background-color: #337ab7;
        border-color: #337ab7;
    }
    .pagination li a {
        position: relative;
        float: left;
        padding: 6px 12px;
        margin-left: -1px;
        line-height: 1.42857143;
        color: #337ab7;
        text-decoration: none;
        background-color: #fff;
        border: 1px solid #ddd;
    }
</style>

@section('content')
    <div class="page-container">

        <div class="mt-20">
            <table class="table table-border table-bordered table-bg table-hover table-sort">
                <thead>
                <tr class="text-c">
                    <th width="40">ID</th>
                    <th>整体评价</th>
                    <th>产品反馈</th>
                    <th>其他建议</th>
                </tr>
                </thead>
                <tbody>
                @foreach($infoLists as $info)
                    <tr class="text-c va-m">
                        <td width="40">{{ $info->id }}</td>
                        <td>
                            @if($info->star < 25)
                                很差
                            @elseif($info->star < 50)
                                不满意
                            @elseif($info->star < 75)
                                一般
                            @elseif($info->star < 100)
                                满意
                            @elseif($info->star == 100)
                                惊喜
                            @else
                                暂无评价
                            @endif
                        </td>
                        <td>
                            @if($info->feedback == 1)
                                太酸
                            @elseif($info->feedback == 2)
                                太甜
                            @elseif($info->feedback == 3)
                                酸甜适合
                            @elseif($info->feedback == 4)
                                浓郁番茄味
                            @elseif($info->feedback == 5)
                                无味
                            @elseif($info->feedback == 6)
                                味道奇怪
                            @elseif($info->feedback == 7)
                                新乡
                            @elseif($info->feedback == 8)
                                不新鲜
                            @else
                                其他
                            @endif
                        </td>
                        <td>{{$info->message}}</td>
                    </tr>
                @endforeach

                </tbody>

            </table>
        </div>
        <div class="dataTables_info">{!! $infoLists->links() !!}</div>
    </div>
@endsection