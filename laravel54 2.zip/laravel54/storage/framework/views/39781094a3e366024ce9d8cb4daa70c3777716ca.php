<?php $__env->startSection('page-title', '宅配卡分类管理'); ?>
<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('style/admin')); ?>/css/sweet-alert.min.css" rel="stylesheet"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title"></h3>
                </div>
                <div class="panel-body">
                    <a href="<?php echo e(route('admin.card.excel.export')); ?>" class="btn btn-info m-b-5" style="float: right">宅配卡模板</a>
                    <button id="cards-excel-import" class="btn btn-info m-b-5"
                            style="float: right; margin-right: 10px;">导入宅配卡
                    </button>
                </div>
                <div class="panel-body">

                    <!-- 导入 -->
                    <?php echo $__env->make('admin.cardExcel.import', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <table id="datatable" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>卡号</th>
                                    <th>卡密</th>
                                    <th>状态</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php if(count($cardExcel) > 0): ?>

                                    <?php $__currentLoopData = $cardExcel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($card->id); ?></td>
                                            <td><?php echo e($card->code); ?></td>
                                            <td><?php echo e($card->code_pw); ?></td>
                                            <td>
                                                <?php if($card->status == 1): ?>
                                                    未使用
                                                <?php else: ?>
                                                    已使用
                                                <?php endif; ?>
                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php else: ?>

                                    <tr>
                                        <td colspan="3">暂无宅配卡</td>
                                    </tr>

                                <?php endif; ?>
                                </tbody>
                            </table>

                            <?php echo $cardExcel->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- End Row -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('admins')); ?>/js/cardExcel.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>