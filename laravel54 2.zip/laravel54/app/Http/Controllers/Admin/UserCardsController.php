<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Service\TokenService;
use Illuminate\Support\Facades\DB;

class UserCardsController extends Controller
{
    //
    public function index()
    {
        $uid = TokenService::getCurrnentUid();

        if (!$uid) {
            return false;
        }

        $userCards = DB::table('user_cards')
            ->select('user_cards.id', 'user_cards.card_code', 'user_cards.number',  'user_cards.number_count', 'user_cards.status', 'users.name')
            ->join('cards', 'cards.number', '=', 'user_cards.number')
            ->join('users', 'users.id', '=', 'user_cards.user_id')
            ->where('user_cards.user_id', $uid)
            ->paginate(10);
//        $userCards = UserCards::paginate(10);

        return view('admin.userCards.index', [
            'userCards' => $userCards
        ]);
    }


}
