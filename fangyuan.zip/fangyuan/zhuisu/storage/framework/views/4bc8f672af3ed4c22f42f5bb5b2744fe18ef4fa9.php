<?php $__env->startSection('title', '绿行者追溯系统'); ?>

<?php $__env->startSection('title_first', '单页管理'); ?>
<?php $__env->startSection('title_secound', '单页列表'); ?>

<?php $__env->startSection('main-title', '列表'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-container">

        <div class="mt-20">
            <table class="table table-border table-bordered table-bg table-hover table-sort">
                <thead>
                <tr class="text-c">
                    <th width="40">ID</th>
                    <th>名称</th>
                    <th>类型</th>
                    <th>操作</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-c va-m">
                        <td><?php echo e($v->id); ?></td>
                        <td><?php echo e($v->title); ?></td>

                        <td>
                            <?php if($v->status == 1): ?>
                                公司介绍
                            <?php elseif($v->status == 2): ?>
                                品牌介绍
                            <?php else: ?>
                                基地介绍
                            <?php endif; ?>
                        </td>

                        <td class="td-manage">
                            <a href="<?php echo e(route('admin.pages.edit', ['id' => $v->id])); ?>">编辑</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.public.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>