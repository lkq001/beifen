<?php $__env->startSection('title', '城市管理'); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">地址列表</h3>
                </div>

                <div class="panel-body">
                    <div class="row">
                        <form action="<?php echo e(route('admin.city.index')); ?>" method="get">
                            <div class="col-md-3 col-sm-3 col-xs-3">
                                <select class="form-control" name="id">
                                    <?php if(!empty($addressLists)): ?>
                                        <?php $__currentLoopData = $addressLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($val->id); ?>"
                                                    <?php if($val->id == $id): ?> selected <?php endif; ?> ><?php echo e($val->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <option value="0">请去添加省份</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <div class="col-md-2 col-sm-2 col-xs-2">
                                <?php if(!empty($addressLists)): ?>

                                    <input type="submit" value="搜索" class="btn btn-info m-b-5"/>

                                <?php endif; ?>
                            </div>
                        </form>
                        <div class="col-md-7 col-sm-7 col-xs-7">
                            <button id="city-add" class="btn btn-info m-b-5" style="float: right">添加城市</button>
                        </div>
                    </div>
                </div>


                <div class="panel-body">

                    <!-- 添加 -->
                    <?php echo $__env->make('admin.city.add', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('admin.city.edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <table id="datatable" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>城市</th>
                                    <th>状态</th>
                                    <th>操作</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php if(count($cityLists) > 0): ?>
                                    <?php $__currentLoopData = $cityLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($v->id); ?></td>
                                            <td><?php echo e($v->name); ?></td>
                                            <td>
                                                <?php if($v->status == 1): ?>
                                                    启用
                                                <?php else: ?>
                                                    禁用
                                                <?php endif; ?>
                                            </td>
                                            <td>

                                                <?php if($v->status == 1): ?>
                                                    <button class="btn-sm btn-info m-b-5 changeEdit"
                                                            data-id="<?php echo e($v->id); ?>" data-pid="<?php echo e($v->pid); ?>"
                                                            data-name="<?php echo e($v->name); ?>">编辑
                                                    </button>
                                                    <button class="btn-sm btn-danger m-b-5 changeStatus"
                                                            data-id="<?php echo e($v->id); ?>"
                                                            data-url="<?php echo e(route('admin.city.status')); ?>"
                                                            data-status="<?php echo e($v->status); ?>">禁用
                                                    </button>
                                                <?php else: ?>
                                                    <button class="btn-sm btn-info m-b-5 changeStatus"
                                                            data-id="<?php echo e($v->id); ?>"
                                                            data-url="<?php echo e(route('admin.city.status')); ?>"
                                                            data-status="<?php echo e($v->status); ?>">启用
                                                    </button>
                                                <?php endif; ?>
                                                <button class="btn-sm btn-danger m-b-5 destroy"
                                                        data-url="<?php echo e(route('admin.city.destroy')); ?>"
                                                        data-id="<?php echo e($v->id); ?>">
                                                    删除
                                                </button>
                                                <a href="<?php echo e(route('admin.area.index', ['id'=> $v->id])); ?>">
                                                    <button class="btn-sm btn-info m-b-5">查看区域</button>
                                                </a>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4" style="text-align: center">暂无城市信息,请添加!</td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                            <?php if(count($cityLists) > 0): ?>
                                <?php echo $cityLists->links(); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div> <!-- End Row -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('admins')); ?>/js/city.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>