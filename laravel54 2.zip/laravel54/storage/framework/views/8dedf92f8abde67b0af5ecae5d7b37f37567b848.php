<?php $__env->startSection('title', '宅配卡管理'); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">订单列表</h3>
                </div>

                <div class="panel-body">

                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <table id="datatable" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>订单编号</th>
                                    <th>订单时间</th>
                                    <th>订单状态</th>
                                    <th>创建时间</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php if($orderLists): ?>
                                    <?php $__currentLoopData = $orderLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($order->id); ?></td>
                                            <td><?php echo e($order->order_no); ?></td>
                                            <td><?php echo e($order->user_id); ?></td>
                                            <td>

                                                <?php if( $order->status  == 1): ?>
                                                    未支付
                                                <?php elseif( $order->status  == 2): ?>
                                                    已支付
                                                <?php elseif( $order->status  == 3): ?>
                                                    已发货
                                                <?php elseif( $order->status  == 4): ?>
                                                    已支付,库存不足
                                                <?php elseif( $order->status  == 5): ?>
                                                    已完成
                                                <?php else: ?>
                                                    其他
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($order->created_at); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                </tbody>
                            </table>
                            <?php echo $orderLists->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div> <!-- End Row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>