<?php

namespace App\Http\Controllers\Admin;

use App\Model\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CategoryController extends Controller
{
    //
    public function index()
    {
        $categorys = Category::paginate('10');
        return view('admin.category.index', [
            'categorys' => $categorys
        ]);
    }

    public function add()
    {

        return view('admin.category.add');
    }

    public function store(Request $request)
    {
        if ($request->name) {
            $category = new Category();
            $category->name = $request->name;
            $category->save();
        }
        return view('admin.category.add');
    }

    public function edit(Request $request)
    {
        $category = Category::where('id', $request->id)->first();

        return view('admin.category.edit', [
            'category' => $category
        ]);
    }

    public function update(Request $request)
    {
        $category = Category::where('id', $request->id)->first();
        if ($request->name) {
            $category->name = $request->name;
            $category->save();
        }
        return view('admin.category.edit', [
            'category' => $category
        ]);
    }

    public function destroy(Request $request)
    {
        $category = Category::where('id', $request->id)->first();

        if (!$category) {
            return [
                'code' => '201',
                'message' => '数据删除失败'
            ];
        }

        $info = Category::where('id', $request->id)->delete();
        if (!$info) {
            return [
                'code' => '201',
                'message' => '数据删除失败'
            ];
        }
        return [
            'code' => '200',
            'message' => '数据删除成功'
        ];
    }
}
