<?php
/**
 *
 *
 * Created by PhpStorm.
 * User: likeqin
 * Date: 2017/12/16
 * Time: 23:31
 * author 李克勤
 */

return [
    'user' => '16'
];