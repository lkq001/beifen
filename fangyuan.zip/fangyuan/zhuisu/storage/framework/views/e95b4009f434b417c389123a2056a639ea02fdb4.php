<?php $__env->startSection('title', '绿行者追溯系统'); ?>

<?php $__env->startSection('title_first', '产品中心'); ?>
<?php $__env->startSection('title_secound', '产品列表'); ?>

<?php $__env->startSection('main-title', '添加产品'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-container">
        <form action="<?php echo e(route('admin.trace.index')); ?>" method="get">
            <div class="text-c"> 产品批次号：
                <input type="text" class="input-text" style="width:250px" placeholder="产品批次号" id="" name="code">
                <button type="submit" class="btn btn-success radius" id="" name=""><i class="Hui-iconfont">&#xe665;</i>
                    搜索
                </button>
            </div>
        </form>
        <div class="mt-20">

            <table class="table table-border table-bordered table-bg table-hover table-sort">

                <thead>
                <tr class="text-c">
                    <th width="40">ID</th>
                    <th>名称</th>
                    <th>产品批次号</th>
                    <th>操作</th>
                    <th>二维码</th>
                    <th>条形码</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $traceLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-c va-m">

                        <td><?php echo e($list->id); ?></td>
                        <td><?php echo e($list->title); ?></td>
                        <td><?php echo e($list->code); ?></td>
                        <td class="td-manage">
                            <a href="<?php echo e(route('admin.trace.edit', ['id' => $list->id])); ?>">编辑</a>
                        </td>

                        <td>
                            <img src="/qrcodes/<?php echo e($list->id); ?>.png" width="100px" height="100px" alt="">
                            <?php echo QrCode::format('png')->size(236)->margin(0)->generate($list->url,public_path('qrcodes/'.$list->id.'.png')); ?>

                            <a href="/qrcodes/<?php echo e($list->id); ?>.bmp" download>点击下载</a>
                        </td>
                        <td>
                            <img src="/<?php echo e($list->code); ?>.png" width="200px" height="80px" alt="">
                            <a href="/<?php echo e($list->code); ?>.png" width="200px" height="80px" download>点击下载</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.public.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>