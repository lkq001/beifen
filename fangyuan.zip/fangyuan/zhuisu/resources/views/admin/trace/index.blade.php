@extends('admin.public.main')

@section('title', '方圆追溯系统')

@section('title_first', '产品中心')
@section('title_secound', '产品列表')

@section('main-title', '添加产品')

@section('content')
    <div class="page-container">
        <form action="{{ route('admin.trace.index') }}" method="get">
            <div class="text-c">
                产品名称：
                <input type="text" onfocus="WdatePicker()" style="width:250px" value="{{ $search['title'] }}" id="commentdatemin" name="commentdatemin" class="input-text">
                产品名称：
                <input type="text" class="input-text" style="width:250px" placeholder="产品名称" id="" value="{{ $search['title'] }}" name="title">
                <button type="submit" class="btn btn-success radius" id="" name=""><i class="Hui-iconfont">&#xe665;</i>
                    搜索
                </button>
            </div>
        </form>
        <div class="mt-20">

            <table class="table table-border table-bordered table-bg table-hover table-sort">

                <thead>
                <tr class="text-c">
                    <th width="40">ID</th>
                    <th>名称</th>
                    <th>产品分类</th>
                    <th>添加时间</th>
                    <th>操作</th>
                    <th>二维码</th>
                </tr>
                </thead>
                <tbody>
                @foreach($traceLists as $list)
                    <tr class="text-c va-m">

                        <td>{{$list->id}}</td>
                        <td>{{$list->title}}</td>
                        <td>{{$list->category_id}}</td>
                        <td>{{$list->created_at}}</td>
                        <td class="td-manage">
                            <a href="{{ route('admin.trace.edit', ['id' => $list->id]) }}">编辑</a>
                        </td>

                        <td>
                            <img src="/qrcodes/{{$list->id}}.png" width="100px" height="100px" alt="">
                            {!! QrCode::format('png')->size(236)->margin(0)->generate($list->url,public_path('qrcodes/'.$list->id.'.png')) !!}
                            <a href="/qrcodes/{{$list->id}}.bmp" download>点击下载</a>
                        </td>
                    </tr>
                @endforeach
                </tbody>

            </table>
        </div>
    </div>
@endsection
