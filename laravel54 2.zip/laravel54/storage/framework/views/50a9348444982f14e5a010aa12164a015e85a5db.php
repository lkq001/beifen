<?php $__env->startSection('page-title', '宅配卡分类管理'); ?>
<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('style/admin')); ?>/css/sweet-alert.min.css" rel="stylesheet"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title"></h3>
                </div>
                <div class="panel-body">
                    <button id="cards-category-add" class="btn btn-info m-b-5" style="float: right">添加分类</button>
                </div>
                <div class="panel-body">

                    <!-- 添加 -->
                    <?php echo $__env->make('admin.cardCategory.add', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <!-- 修改 -->
                    <?php echo $__env->make('admin.cardCategory.edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <table id="datatable" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>分类名称</th>
                                    <th>操作</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php if(count($cardCategorys) > 0): ?>

                                    <?php $__currentLoopData = $cardCategorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($category->id); ?></td>
                                            <td><?php echo e($category->name); ?></td>
                                            <td>
                                                <button id="card-categorys-edit" class="btn-xs btn-info btn-rounded m-b-5" data-id="<?php echo e($category->id); ?>" data-url="<?php echo e(route('admin.cards.category.edit')); ?>">编辑</button>
                                                <button id="card-categorys-destroy" class="btn-xs btn-danger btn-rounded m-b-5" data-id="<?php echo e($category->id); ?>" data-url="<?php echo e(route('admin.cards.category.destroy')); ?>">删除</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php else: ?>

                                    <tr>
                                        <td colspan="3">暂无宅配卡分类</td>
                                    </tr>

                                <?php endif; ?>
                                </tbody>
                            </table>

                            <?php echo $cardCategorys->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- End Row -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('admins')); ?>/js/cardsCategory.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>