<footer class="footer">
    2016 © Velonic.
</footer>