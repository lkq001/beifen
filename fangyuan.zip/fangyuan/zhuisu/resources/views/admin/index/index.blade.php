@extends('admin.public.main')

@section('title', 'Page Title')
@section('main-title', '后台首页')

@section('content')
    <p>This is my body content</p>
@endsection