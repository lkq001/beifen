<?php $__env->startSection('title', 'Page Title'); ?>
<?php $__env->startSection('main-title', '后台首页'); ?>

<?php $__env->startSection('content'); ?>
    <p>This is my body content</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.public.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>