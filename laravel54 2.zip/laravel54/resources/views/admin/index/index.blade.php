@extends('admin.layouts.index')
@section('title', '首页管理')
@section('style')
@endsection
@section('content')
    welcome
@endsection