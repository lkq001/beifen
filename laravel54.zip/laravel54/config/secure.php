<?php
/**
 *
 *
 * Created by PhpStorm.
 * User: likeqin
 * Date: 2017/12/16
 * Time: 23:31
 * author 李克勤
 */

return [
    'token_salt' => 'WrqfDD1LtDlPMtub',
    'pay_back_url' => 'http://lkq.laravel54.com/api/pay/notify'
];