<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>

<!-- Aside Start-->
<?php echo $__env->make('admin.layouts.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Aside Ends-->


<!--Main Content Start -->
<section class="content">

<?php echo $__env->make('admin.layouts.top', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Page Content Start -->
    <!-- ================== -->

    <div class="wraper container-fluid">
        <div class="panel-heading">
            <h3 class="panel-title"><?php echo $__env->yieldContent('page-title'); ?></h3>
        </div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- Page Content Ends -->
    <!-- ================== -->

    <!-- Footer Start -->
        <?php echo $__env->make('admin.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Footer Ends -->


</section>
    <?php echo $__env->make('admin.layouts.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>
