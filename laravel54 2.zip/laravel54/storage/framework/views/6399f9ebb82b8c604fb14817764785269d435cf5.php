<?php $__env->startSection('title', '宅配卡管理'); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">宅配计划列表</h3>
                </div>
                
                    
                
                <div class="panel-body">

                    <!-- 添加 -->
                    
                    
                    
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <table id="datatable" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>宅配卡编号</th>
                                    <th>次数</th>
                                    <th>宅配时间</th>
                                    <th>使用人</th>
                                    <th>电话</th>
                                    <th>使用地址</th>
                                    <th>状态</th>
                                    
                                </tr>
                                </thead>

                                <tbody>
                                <?php if($useCards): ?>
                                    <?php $__currentLoopData = $useCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($card->id); ?></td>
                                            <td><?php echo e($card->card_id); ?></td>
                                            <td><?php echo e($card->card_use); ?></td>
                                            <td><?php echo e($card->use_time); ?></td>
                                            <td><?php echo e($card->user_name); ?></td>
                                            <td><?php echo e($card->tel); ?></td>
                                            <td><?php echo e($card->address); ?></td>
                                            <td>

                                                <?php if( $card->status  == 1): ?>
                                                    未配送
                                                <?php elseif( $card->status  == 2): ?>
                                                    已配送
                                                <?php else: ?>
                                                    其他
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                </tbody>
                            </table>
                            <?php echo $useCards->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div> <!-- End Row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('admins')); ?>/js/cards.js"></script>
    <script id="ueditor"></script>
    <script>
        var ue = UE.getEditor("ueditor");
        ue.ready(function () {
            //因为Laravel有防csrf防伪造攻击的处理所以加上此行
            ue.execCommand('serverparam', '_token', '<?php echo e(csrf_token()); ?>');
        });
    </script>

    <script id="editueditor"></script>
    <script>
        var ue = UE.getEditor("editueditor");
        ue.ready(function () {
            //因为Laravel有防csrf防伪造攻击的处理所以加上此行
            ue.execCommand('serverparam', '_token', '<?php echo e(csrf_token()); ?>');
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>