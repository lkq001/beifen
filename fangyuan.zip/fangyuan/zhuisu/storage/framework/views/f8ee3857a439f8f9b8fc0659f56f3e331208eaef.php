<?php $__env->startSection('title', '绿行者追溯系统'); ?>
<?php $__env->startSection('title_first', '单页管理'); ?>
<?php $__env->startSection('main_title', '修改'); ?>


<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('admin.pages.update')); ?>" method="post" class="form form-horizontal"
          enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="id" value="<?php echo e($info->id); ?>">
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2">
                <span class="c-red">*</span>
                名称：</label>
            <div class="formControls col-xs-6 col-sm-6">
                <input type="text" class="input-text" value="<?php echo e($info->title); ?>" placeholder="" name="title">
            </div>
        </div>


        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2">备注：</label>
            <div class="formControls col-xs-6 col-sm-6">
                <div id="ueditor" class="edui-default" data-content="<?php echo e($info->content); ?>">
                    <?php echo $__env->make('UEditor::head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>

        <div class="row cl">
            <div class="col-9 col-offset-2">
                <input class="btn btn-primary radius" type="submit" value="&nbsp;&nbsp;提交&nbsp;&nbsp;">
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script id="ueditor"></script>
    <script>
        var ue = UE.getEditor("ueditor");
        ue.ready(function () {
            ue.setContent($('#ueditor').attr('data-content'));

            //因为Laravel有防csrf防伪造攻击的处理所以加上此行
            ue.execCommand('serverparam', '_token', '<?php echo e(csrf_token()); ?>');
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.public.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>