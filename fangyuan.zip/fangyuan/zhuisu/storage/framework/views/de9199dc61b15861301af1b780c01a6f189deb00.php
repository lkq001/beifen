<?php $__env->startSection('title', '绿行者追溯系统'); ?>

<?php $__env->startSection('title_first', '产品中心'); ?>
<?php $__env->startSection('title_secound', '产品列表'); ?>

<?php $__env->startSection('main-title', '添加产品'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-container">

        <div class="mt-20">
            <table class="table table-border table-bordered table-bg table-hover table-sort">
                <thead>
                <tr class="text-c">
                    <th width="40">ID</th>
                    <th>名称</th>
                    <th>操作</th>
                    <th>二维码</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $traceLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-c va-m">
                        <td><?php echo e($list->id); ?></td>
                        <td><?php echo e($list->title); ?></td>
                        <td class="td-manage">
                            <a href="<?php echo e(route('admin.trace.edit', ['id' => $list->id])); ?>">编辑</a>
                        </td>

                        <td>
                            <?php echo QrCode::size(100)->generate($list->url);; ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.public.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>