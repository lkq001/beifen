<?php

return [

    'URL' => [
        'image' =>  env('IMG_PATH'),
    ],
    'system' => [
        'title' => '绿行者'
    ]
];