<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Model\CardUse;
use App\Service\TokenService;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Validator;


class CardUseController extends Controller
{
    protected static $cardUse;
    protected static $cards;

    public function __construct(
        CardUse $cardUse,
        Cards $cards
    )
    {
        self::$cardUse = $cardUse;
        self::$cards = $cards;
    }

    //
    public function index(Request $request)
    {
        $uid = TokenService::getCurrnentUid();

        if (!$uid) {
            return false;
        }

        $useCards = DB::table('user_cards')
            ->select('user_cards.id', 'user_cards.card_code', 'user_cards.number', 'user_cards.status', 'cards.name as cards_name', 'users.name')
            ->join('cards', 'cards.number', '=', 'user_cards.number')
            ->join('users', 'users.user_id', '=', 'user_cards.user_id')
            ->where('user_cards.user_id', $uid)
            ->paginate(10);
//        $useCards = self::$cardUse->where('status', '>', '0')->orderBy('use_time')->paginate(10);

        return view('admin.cardUse.index', [
            'useCards' => $useCards
        ]);
    }

    // 宅配卡使用
    public function toUseCardById(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id' => 'required'
        ]);

        if ($validator->fails()) {
            return response()->json([401, $validator->errors()->first()]);
        }

        $card = new CardUse();

        $cardInfo = CardUse::where('id', $request->id)->where('status', 1)->first();

        $cardInfo->status = 2;

        if ($cardInfo->save()) {
            return [
                'status' => '200',
                'message' => '操作成功'
            ];
        }
        return [
            'status' => '400',
            'message' => '操作成功'
        ];


    }
}
