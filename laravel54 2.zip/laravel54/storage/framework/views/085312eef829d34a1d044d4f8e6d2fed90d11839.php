<?php $__env->startSection('title', '幻灯片管理'); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">幻灯片列表</h3>
                </div>
                <div class="panel-body">
                    <button id="banners-add" class="btn btn-info m-b-5" style="float: right">添加</button>
                </div>
                <div class="panel-body">

                    <!-- 添加 -->
                    <?php echo $__env->make('admin.banners.add', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <!-- 修改 -->
                    <?php echo $__env->make('admin.banners.edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <table id="datatable" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>名称</th>
                                    <th>幻灯片</th>
                                    <th>状态</th>
                                    <th>操作</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($banner->id); ?></td>
                                        <td><?php echo e($banner->name); ?></td>
                                        <td><img src="<?php echo e('http://p0ztvlsi6.bkt.clouddn.com/' . $banner->image); ?>" style="width: 100px" alt=""></td>
                                        <td>

                                            <?php if( $banner->status  == 1): ?>
                                                展示
                                            <?php else: ?>
                                                隐藏
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <button id="banners-edit" class="btn-xs btn-info btn-rounded m-b-5"
                                                    data-id="<?php echo e($banner->id); ?>"
                                                    data-url="<?php echo e(route('admin.banners.edit')); ?>">编辑
                                            </button>
                                            <button id="banners-destroy" class="btn-xs btn-danger btn-rounded m-b-5"
                                                    data-id="<?php echo e($banner->id); ?>"
                                                    data-url="<?php echo e(route('admin.banners.destroy')); ?>">删除
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div> <!-- End Row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('admins')); ?>/js/banners.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>