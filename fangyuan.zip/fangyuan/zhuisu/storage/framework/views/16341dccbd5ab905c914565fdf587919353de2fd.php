<?php $__env->startSection('title', '方圆追溯系统'); ?>

<?php $__env->startSection('title_first', '评价管理'); ?>
<?php $__env->startSection('title_secound', '评价列表'); ?>

<?php $__env->startSection('main-title', '评价'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-container">

        <div class="mt-20">
            <table class="table table-border table-bordered table-bg table-hover table-sort">
                <thead>
                <tr class="text-c">
                    <th width="40">ID</th>
                    <th>整体评价</th>
                    <th>产品反馈</th>
                    <th>其他建议</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $infoLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-c va-m">
                        <td width="40"><?php echo e($info->id); ?></td>
                        <td>
                            <?php if($info->star < 25): ?>
                                很差
                            <?php elseif($info->star < 50): ?>
                                不满意
                            <?php elseif($info->star < 75): ?>
                                一般
                            <?php elseif($info->star < 100): ?>
                                满意
                            <?php elseif($info->star == 100): ?>
                                惊喜
                            <?php else: ?>
                                暂无评价
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($info->feedback == 1): ?>
                                太酸
                            <?php elseif($info->feedback == 2): ?>
                                太甜
                            <?php elseif($info->feedback == 3): ?>
                                酸甜适合
                            <?php elseif($info->feedback == 4): ?>
                                浓郁番茄味
                            <?php elseif($info->feedback == 5): ?>
                                无味
                            <?php elseif($info->feedback == 6): ?>
                                味道奇怪
                            <?php elseif($info->feedback == 7): ?>
                                新乡
                            <?php elseif($info->feedback == 8): ?>
                                不新鲜
                            <?php else: ?>
                                其他
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($info->message); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.public.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>