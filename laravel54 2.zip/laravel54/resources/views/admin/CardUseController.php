<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Model\Cards;
use App\Model\CardUse;
use Illuminate\Http\Request;
use Excel;

class CardUseController extends Controller
{
    protected static $cardUse;
    protected static $cards;

    public function __construct(
        CardUse $cardUse,
        Cards $cards
    )
    {
        self::$cardUse = $cardUse;
        self::$cards = $cards;
    }

    //
    public function index(Request $request)
    {

        if ($request->tel) {
          $useCards = CardUse::where('tel', $request->tel)
          ->where('status', '>', '0')
          ->orderBy('use_time')->paginate(10);
        } else {
          $useCards = CardUse::where('status', '>', '0')->orderBy('use_time')->paginate(10);
        }

        return view('admin.cardUse.index', [
            'useCards' => $useCards,
            'tel' => $request->tel ?? ''
        ]);
    }

    // 导出
    public function export(Request $request)
    {
        if ($request->tel) {
          $useCards = CardUse::where('tel', $request->tel)
          ->where('status', '>', '0')
          ->orderBy('use_time')->paginate(10);
        } else {
          $useCards = CardUse::where('status', '>', '0')->orderBy('use_time')->paginate(10);
        }
        
        $cellData = [
            ['学号','姓名','成绩'],
            ['10001','AAAAA','99'],
            ['10002','BBBBB','92'],
            ['10003','CCCCC','95'],
            ['10004','DDDDD','89'],
            ['10005','EEEEE','96'],
        ];

        Excel::create('学生成绩',function($excel) use ($cellData){

            $excel->sheet('score', function($sheet) use ($cellData){
                $sheet->rows($cellData);
            });

        })->export('xls');
    }
}
