<div id="city-add-modal" class="modal fade" aria-labelledby="custom-width-modalLabel" aria-hidden="true"
     style="display: none;">
    <div class="modal-dialog" style="width:55%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title" id="custom-width-modalLabel">添加城市</h4>
            </div>
            <div class="modal-body">

                <form class="cmxform form-horizontal tasi-form" action="<?php echo e(route('admin.city.store')); ?>" method="post"
                      enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group ">
                        <label for="cname" class="control-label col-lg-2">省份</label>
                        <div class="col-lg-10">
                            <select class="form-control" name="pid">
                                <?php if(!empty($addressLists)): ?>
                                    <?php $__currentLoopData = $addressLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($val->id); ?>"
                                                <?php if($val->id == $id): ?> selected <?php endif; ?> ><?php echo e($val->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <option value="0">请去添加省份</option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group ">
                        <label for="cname" class="control-label col-lg-2">城市</label>
                        <div class="col-lg-10">
                            <input class=" form-control" name="name" type="text" required="" aria-required="true">
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
                        <input type="submit" class="btn btn-primary" value="添加"/>
                    </div>
                </form>


            </div>

        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>