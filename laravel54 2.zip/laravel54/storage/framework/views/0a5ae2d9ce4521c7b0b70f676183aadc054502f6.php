<?php $__env->startSection('page-title', '用户管理'); ?>
<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('style/admin')); ?>/css/sweet-alert.min.css" rel="stylesheet"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title"></h3>
                </div>
                <div class="panel-body">
                    <button id="users-add" class="btn btn-info m-b-5" style="float: right">添加用户</button>
                </div>
                <div class="panel-body">

                    <!-- 添加 -->
                    <?php echo $__env->make('admin.users.add', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <!-- 修改 -->
                    <?php echo $__env->make('admin.users.edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <table id="datatable" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>用户名</th>
                                    <th>操作</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php if(count($users) > 0): ?>

                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($user->id); ?></td>
                                            <td><?php echo e($user->name); ?></td>
                                            <td>
                                                <button id="users-edit" class="btn-xs btn-info btn-rounded m-b-5" data-id="<?php echo e($user->id); ?>" data-url="<?php echo e(route('admin.users.edit')); ?>">编辑</button>
                                                <button id="users-destroy" class="btn-xs btn-danger btn-rounded m-b-5" data-id="<?php echo e($user->id); ?>" data-url="<?php echo e(route('admin.users.destroy')); ?>">删除</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php else: ?>

                                    <tr>
                                        <td colspan="3">暂无用户信息</td>
                                    </tr>

                                <?php endif; ?>
                                </tbody>
                            </table>

                            <?php echo $users->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- End Row -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('admins')); ?>/js/users.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>