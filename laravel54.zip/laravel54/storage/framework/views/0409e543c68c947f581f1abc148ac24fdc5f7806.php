<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo e(asset('style/admin')); ?>/js/jquery.js"></script>
<script src="<?php echo e(asset('style/admin')); ?>/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('style/admin')); ?>/js/wow.min.js"></script>
<script src="<?php echo e(asset('style/admin')); ?>/js/jquery.scrollto.min.js"></script>
<script src="<?php echo e(asset('style/admin')); ?>/js/jquery.nicescroll.js" type="text/javascript"></script>

<!-- sparkline -->
<script src="<?php echo e(asset('style/admin')); ?>/js/jquery.sparkline.min.js" type="text/javascript"></script>
<script src="<?php echo e(asset('style/admin')); ?>/js/chart-sparkline.js" type="text/javascript"></script>

<!-- skycons -->
<script src="<?php echo e(asset('style/admin')); ?>/js/skycons.min.js" type="text/javascript"></script>

<script src="<?php echo e(asset('style/admin')); ?>/js/pace.min.js"></script>
<script src="<?php echo e(asset('style/admin')); ?>/js/classie.js"></script>
<script src="<?php echo e(asset('style/admin')); ?>/js/modaleffects.js"></script>
<script src="<?php echo e(asset('style/admin')); ?>/js/jquery.app.js"></script>

<script src="<?php echo e(asset('style/admin')); ?>/js/sweet-alert.min.js"></script>

