@extends('admin.public.main')

@section('title', '方圆追溯系统')
@section('title_first', '单页管理')
@section('main_title', '添加')


@section('content')
    <form action="{{route('admin.category.store')}}" method="post" class="form form-horizontal">
        {{ csrf_field() }}
        <div class="row cl">
            <label class="form-label col-xs-4 col-sm-2">
                <span class="c-red">*</span>
                名称：</label>
            <div class="formControls col-xs-6 col-sm-6">
                <input type="text" class="input-text" value="" placeholder="" name="name">
            </div>
        </div>

        <div class="row cl">
            <div class="col-9 col-offset-2">
                <input class="btn btn-primary radius" type="submit" value="&nbsp;&nbsp;提交&nbsp;&nbsp;">
            </div>
        </div>
    </form>
@endsection